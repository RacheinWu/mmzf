let HTTP_NAME = "localhost/api/";

let DRAFT_ADD = "draft/add";
let DRAFT_REMOVE = "draft/remove";
let DRAFT_GET = "draft/list/";//{page}
let ARTICLE_RELEASE = "article/release";
let ARTICLE_RELEASE_SUCCESS_ALL = "article/success/all";
let ARTICLE_RELEASE_SUCCESS_DELETE = "article/success/delete";